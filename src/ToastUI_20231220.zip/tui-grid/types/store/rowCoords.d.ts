export interface RowCoords {
  heights: number[];
  readonly offsets: number[];
  readonly totalRowHeight: number;
}
